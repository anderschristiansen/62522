package com.roskildeapp.database;

import java.util.List;

import android.content.Context;
import android.graphics.LightingColorFilter;
import android.util.Log;

import com.parse.FindCallback;
import com.parse.Parse;
import com.parse.ParseAnalytics;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.roskildeapp.LoginActivity;
import com.roskildeapp.objects.User;



public class DatabaseHandler {

//	public DatabaseHandler(Context context) {
//		Parse.initialize(context, "1PZGZUbJ7AyTkIZTOwMfXxdFRpkbJwo0MoB4J6im", "rkXj2TIHo48jhTXSX9YQthqXYseSSWzUBGT2HoqF");
//	}

	public DatabaseHandler(){
		
	}
}
